<?php 
 $connect = mysqli_connect('localhost','root','','hunahee');
    mysqli_set_charset($connect,'utf8');
 ?>